# Apex Legends

Apex Legends is a first person shooter battle royale. This game took over the scene after starting as a sequal to TitanFall.