from django.shortcuts import render
import markdown

from . import util

# I spend way too much time trying to download django,
# after I finally made the computer agree, after running server,
# I recieved the error "no module named markdown2 found",
# after scouring for fixes to the given markdown help, I found out,
# that I was running server without python(3) where the three changed everything

def convert_to_html(title):
    content = util.get_entry(title)
    markdowner = markdown.Markdown()
    if content == None:
        return None
    else:
        return markdowner.convert(content)

def index(request):
    return render(request, "encyclopedia/index.html", {
        "entries": util.list_entries()
    })

def entry(request, title):
    html_content = convert_to_html(title)
    if html_content == None:
        return render(request, "encyclopedia/error_message.html", {
            "message": "This Entry Does Not Exist"
        })
    else:
        return render(request, "encyclopedia/entry.html", {
            "title": title,
            "content": html_content
        })
    
def search(request):
    if request.method == "POST":
        entry_search = request.POST['q']
        html_content = convert_to_html(entry_search)
        if html_content is not None:
            return render(request, "encyclopedia/entry.html", {
                "title": entry_search,
                "content": html_content
        })
        else:
            all_entries = util.list_entries()
            recommended = []
            for entry in all_entries:
                if entry_search.lower() in entry.lower():
                    recommended.append(entry)
            return render(request, "encyclopedia/search.html", {
                "recommended": recommended
            })
        
def create_new_page(request):
    if request.method == "GET":
        return render(request, "encyclopedia/create_new_page.html")


'''
I tried doing this at first (coupled with the other apex comments)
def apex(request):
    return render(request, "encyclopedia/apex.html", {
        "entries": util.list_entries()
    })
'''



